# Vivado HLS 2019.2 -- neural NMS LDPC decoder, final design, board top nnms_axi (AXI-Lite)
# Usage (Vivado HLS 2019.2 Command Prompt, from this folder):   vivado_hls -f run_hls.tcl
# The IP export includes the workaround for the 2019.2 date bug (AMD AR 76960), so it
# also works on machines without the y2k22 patch.
set do_csim   1
set do_csynth 1
set do_cosim  1
set do_export 1

set proj nnms_hls
set sol  sol_150MHz

open_project -reset $proj
set_top nnms_axi
add_files nnms_decoder.cpp -cflags "-std=c++0x"
add_files -tb tb_nnms.cpp   -cflags "-std=c++0x"
add_files -tb golden

open_solution -reset $sol
set_part {xc7z020clg484-1}
create_clock -period 6.667 -name default        ;# 150 MHz
set_clock_uncertainty 12.5%

if {$do_csim}   { csim_design -clean }
if {$do_csynth} { csynth_design }
if {$do_cosim}  { cosim_design -rtl verilog -trace_level none }

if {$do_export} {
    set ipdir [file normalize [file join [pwd] $proj $sol impl ip]]
    if {[catch {export_design -format ip_catalog -rtl verilog \
                 -description "Quantized neural NMS LDPC decoder, 5G NR BG2 Z=16, AXI-Lite" \
                 -vendor "kfu.edu.sa" -library "ldpc" -version "1.0"} err]} {
        puts "IP packaging failed ($err) - applying the core_revision fix and packaging again"
        set f [file join $ipdir run_ippack.tcl]
        set fh [open $f r]; set txt [read $fh]; close $fh
        set txt [string map [list {core_revision $Revision} {core_revision 1901010000}] $txt]
        set fh [open $f w]; puts -nonewline $fh $txt; close $fh
        # Vivado cannot be started from inside vivado_hls on Windows (library path clash),
        # so the packaging step is run by hand from a fresh command prompt:
        puts "run_ippack.tcl is fixed. Now package the IP from a Vivado HLS Command Prompt:"
        puts "  cd /d [file nativename $ipdir]"
        puts "  vivado -mode batch -notrace -source run_ippack.tcl"
    }
    puts "IP folder: $ipdir"
}
exit
