# ZedBoard test of the neural NMS LDPC decoder (final design)

The final design is the version 1 decoder core (5.63 ns estimated, 9,037 LUT, 0 DSP), unchanged,
inside an AXI-Lite wrapper so the ARM can write inputs and read results directly. The
merged-loop variant tried as version 2 is kept in `archive/` only: it failed timing (16.5 ns).

Verified here: the HLS C model of the final design is bit-exact with the Python golden model on
all 600 frames (all 352 posteriors, decoded bits, iteration counts). The ARM test program, with
mock Xilinx headers routing register accesses to that C model, also prints PASS. Everything
that needs Vivado, Vitis or the board still has to run on your machine.

## 1. HLS: synthesize and export (Vivado HLS 2019.2 Command Prompt)

```
cd /d C:\work\ldpc_neural_ms\hls_final
vivado_hls -f run_hls.tcl
```
Expected output: C simulation `PASS: final design is bit-exact ...`, then synthesis,
`C/RTL co-simulation finished: PASS`. If the date bug stops the IP export, the script fixes
`run_ippack.tcl` and prints two commands. Run them in the same Command Prompt:
```
cd /d C:\work\ldpc_neural_ms\hls_final\nnms_hls\sol_150MHz\impl\ip
vivado -mode batch -notrace -source run_ippack.tcl
```
Send `nnms_hls\sol_150MHz\syn\report\nnms_axi_csynth.rpt` and `nnms_core_csynth.rpt`.

## 2. Vivado: build the ZedBoard hardware (Vivado 2019.2)

```
cd /d C:\work\ldpc_neural_ms\board
vivado -mode batch -notrace -source build_zedboard.tcl
```
or Vivado GUI: Tools > Run Tcl Script > `build_zedboard.tcl`. It takes about 10-20 minutes.
The script creates the Zynq PS with the ZedBoard preset, adds the decoder on M_AXI_GP0,
implements it, and writes:
- `vivado_zed\nnms_zed.xsa`: hardware platform with bitstream, for Vitis
- `reports\utilization.rpt`, `timing_summary.rpt`, `power.rpt`: post-route numbers for the paper

First bring-up runs the PL at 100 MHz (`set fclk_mhz 100` at the top of the script).
For the paper, set 150, run again, and check that the printed WNS is positive.

## 3. Vitis 2019.2: build and run the test program

1. Start Vitis 2019.2 and pick a workspace, for example `C:\work\ldpc_neural_ms\board\vitis_ws`.
2. File > New > Application Project. Name: `nnms_test`.
3. Platform: Create a new platform from hardware (XSA), and browse to `vivado_zed\nnms_zed.xsa`.
4. Processor `ps7_cortexa9_0`, OS **standalone**, language C, template **Empty Application**.
5. Copy `sw\main.c` and `sw\golden_vectors.h` into the application's `src` folder.
6. Build (hammer icon).
7. Connect the ZedBoard: power, the USB-JTAG cable (J17), and the USB-UART cable (J14). Set the
   boot-mode jumpers to JTAG. Open a serial terminal at 115200 baud: the Vitis Terminal tab,
   PuTTY, or Tera Term.
8. Right-click `nnms_test` > Run As > Launch on Hardware (System Debugger).

Expected serial output:
```
Neural NMS LDPC decoder board test, 600 golden frames
10 iterations     : 0 mismatching, NN.NN us per decode
early termination : 0 mismatching, NN.NN us per decode, 6.08 iterations
PASS: board decoder is bit-exact with the Python golden model
```
The "us per decode" figures are measured on the board from start to done. They include
unpacking the 60 input words and packing the result, but not the ARM's AXI-Lite transfers.

## If the build fails

- `xnnms_axi_hw.h` macro names differ: open that file in the BSP
  (`<platform>\...\include\xnnms_axi_hw.h`) and match the `#define` names used in `main.c`.
- `XPAR_..._BASEADDR` missing: the program falls back to 0x43C00000. The address printed at the
  end of `build_zedboard.tcl` shows the real one.
- "board part not found": install the ZedBoard board files (Avnet board-files repository) or
  select the board once in the Vivado GUI.
