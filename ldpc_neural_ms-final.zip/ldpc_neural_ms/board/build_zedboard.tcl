# build_zedboard.tcl -- Vivado 2019.2: ZedBoard design with the Zynq PS and the HLS decoder
#
# Usage (Vivado 2019.2 Tcl Shell, or Vivado HLS Command Prompt), from this board folder:
#   vivado -mode batch -notrace -source build_zedboard.tcl
# or in the Vivado GUI: Tools > Run Tcl Script... > build_zedboard.tcl
#
# Needs: the IP exported by ../hls_final/run_hls.tcl
# Produces: vivado_zed/nnms_zed.xsa (hardware + bitstream for Vitis) and post-route reports
#           reports/utilization.rpt, reports/timing_summary.rpt, reports/power.rpt

set fclk_mhz 100          ;# PL clock. 100 MHz for first bring-up; set 150 for the paper numbers
set proj     nnms_zed
set proj_dir [file normalize vivado_zed]
set ip_repo  [file normalize ../hls_final/nnms_hls/sol_150MHz/impl/ip]
set jobs     4

if {![file exists [file join $ip_repo component.xml]]} {
    puts "ERROR: HLS IP not found in $ip_repo. Run ../hls_final/run_hls.tcl first."
    return
}

create_project $proj $proj_dir -part xc7z020clg484-1 -force
set bp [lindex [lsort [get_board_parts -quiet *avnet*zed*]] end]
if {$bp eq ""} { set bp [lindex [lsort [get_board_parts -quiet *zed*]] end] }
if {$bp ne ""} {
    set_property board_part $bp [current_project]
    puts "Board part: $bp"
} else {
    puts "WARNING: ZedBoard board files not found; the PS DDR preset cannot be applied."
}
set_property ip_repo_paths [list $ip_repo] [current_project]
update_ip_catalog

# ---------------------------------------------------------------- block design
create_bd_design "system"
set ps [create_bd_cell -type ip -vlnv xilinx.com:ip:processing_system7:5.5 processing_system7_0]
apply_bd_automation -rule xilinx.com:bd_rule:processing_system7 \
    -config {make_external "FIXED_IO, DDR" apply_board_preset "1" Master "Disable" Slave "Disable"} $ps
set_property -dict [list CONFIG.PCW_FPGA0_PERIPHERAL_FREQMHZ $fclk_mhz] $ps

set dec [create_bd_cell -type ip -vlnv kfu.edu.sa:ldpc:nnms_axi:1.0 nnms_axi_0]
apply_bd_automation -rule xilinx.com:bd_rule:axi4 \
    -config {Clk_master {Auto} Clk_slave {Auto} Clk_xbar {Auto} Master {/processing_system7_0/M_AXI_GP0} Slave {/nnms_axi_0/s_axi_ctrl} intc_ip {New AXI Interconnect} master_apm {0}} \
    [get_bd_intf_pins nnms_axi_0/s_axi_ctrl]

assign_bd_address
validate_bd_design
save_bd_design

set wrapper [make_wrapper -files [get_files system.bd] -top]
add_files -norecurse $wrapper
set_property top system_wrapper [current_fileset]
update_compile_order -fileset sources_1

# ---------------------------------------------------------------- implement
launch_runs impl_1 -to_step write_bitstream -jobs $jobs
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {
    puts "ERROR: implementation did not finish; open $proj_dir/$proj.xpr and check the run log."
    return
}

open_run impl_1
file mkdir reports
report_utilization       -file reports/utilization.rpt
report_utilization -hierarchical -file reports/utilization_hier.rpt
report_timing_summary    -file reports/timing_summary.rpt
report_power             -file reports/power.rpt
set wns [get_property STATS.WNS [get_runs impl_1]]
puts "Post-route WNS at $fclk_mhz MHz: $wns ns  ([expr {$wns >= 0 ? "timing met" : "TIMING FAILED"}])"

write_hw_platform -fixed -include_bit -force -file [file join $proj_dir $proj.xsa]
puts "Hardware platform: [file join $proj_dir $proj.xsa]"
catch {
    open_bd_design [get_files system.bd]
    foreach seg [get_bd_addr_segs -of_objects [get_bd_addr_spaces processing_system7_0/Data]] {
        puts "Address: [get_property NAME $seg]  [get_property OFFSET $seg]"
    }
}
