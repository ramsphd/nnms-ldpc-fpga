"""5G NR base graph 2 (BG2) LDPC code: loading, lifting, rate selection and encoding.

The BG2 shift table (data/5G_bg2.csv) is 3GPP TS 38.212 Table 5.3.2-3, taken from
NVIDIA Sionna (Apache-2.0). We use all 10 information columns (K = 10*Z, no filler
bits) and keep the first m base-graph rows, which gives a BG2-derived code with

    N_mother = (10 + m) * Z,   transmitted bits N_tx = (8 + m) * Z  (first 2Z punctured),
    code rate R = 10 / (8 + m)   ->  m = 12 gives R = 1/2,  m = 22 gives R = 10/30 ~ 1/3.
"""
from pathlib import Path
import numpy as np

# Lifting-size sets, TS 38.212 Table 5.3.2-1
LIFTING_SETS = [
    [2, 4, 8, 16, 32, 64, 128, 256],
    [3, 6, 12, 24, 48, 96, 192, 384],
    [5, 10, 20, 40, 80, 160, 320],
    [7, 14, 28, 56, 112, 224],
    [9, 18, 36, 72, 144, 288],
    [11, 22, 44, 88, 176, 352],
    [13, 26, 52, 104, 208],
    [15, 30, 60, 120, 240],
]
_CSV = Path(__file__).parent / "data" / "5G_bg2.csv"


def set_index(z):
    for i, s in enumerate(LIFTING_SETS):
        if z in s:
            return i
    raise ValueError(f"Z={z} is not a valid 5G NR lifting size")


def load_bg2(i_ls):
    """Return the 42x52 BG2 shift matrix for set index i_ls (-1 = zero block)."""
    bm = -np.ones((42, 52), dtype=int)
    tab = np.genfromtxt(_CSV, delimiter=";")
    r_ind = 0
    for r in range(2, tab.shape[0]):
        if not np.isnan(tab[r, 0]):
            r_ind = int(tab[r, 0])
        bm[r_ind, int(tab[r, 1])] = int(tab[r, i_ls + 2])
    return bm


def gf2_inv(a):
    """Inverse of a square binary matrix over GF(2) (Gauss-Jordan)."""
    n = a.shape[0]
    m = np.concatenate([a.astype(np.uint8) % 2, np.eye(n, dtype=np.uint8)], axis=1)
    for col in range(n):
        piv = np.nonzero(m[col:, col])[0]
        if piv.size == 0:
            raise np.linalg.LinAlgError("matrix is singular over GF(2)")
        p = col + piv[0]
        if p != col:
            m[[col, p]] = m[[p, col]]
        rows = np.nonzero(m[:, col])[0]
        rows = rows[rows != col]
        m[rows] ^= m[col]
    return m[:, n:]


class BG2Code:
    """BG2-derived QC-LDPC code with lifting size Z and m base-graph rows."""

    def __init__(self, Z=16, m=12):
        if not 4 <= m <= 42:
            raise ValueError("m must be between 4 (core) and 42")
        self.Z, self.m = Z, m
        self.i_ls = set_index(Z)
        bm_full = load_bg2(self.i_ls)
        self.bm_raw = bm_full[:m, : 10 + m]
        self.shift = np.where(self.bm_raw >= 0, self.bm_raw % Z, -1)  # V mod Z
        self.K = 10 * Z
        self.N = (10 + m) * Z
        self.M = m * Z
        self.n_punct = 2 * Z
        self.N_tx = self.N - self.n_punct
        self.rate = self.K / self.N_tx

        # Lifted parity-check matrix (dense, small codes only)
        H = np.zeros((self.M, self.N), dtype=np.uint8)
        im = np.arange(Z)
        # Layer description used by the layered decoders:
        #   layer_idx[r]  : (Z, d_r) array, VN index of edge e of check j in layer r
        #   layer_eid[r]  : (d_r,)   base-graph edge ids (for neural weight sharing)
        #   layer_cols[r], layer_shift[r] : base column and shift of each edge (for HW export)
        self.layer_idx, self.layer_eid, self.layer_cols, self.layer_shift = [], [], [], []
        eid = 0
        for r in range(m):
            cols = np.nonzero(self.shift[r] >= 0)[0]
            idx = np.zeros((Z, len(cols)), dtype=np.int64)
            for e, c in enumerate(cols):
                vn = c * Z + (im + self.shift[r, c]) % Z
                H[r * Z + im, vn] = 1
                idx[:, e] = vn
            self.layer_idx.append(idx)
            self.layer_eid.append(np.arange(eid, eid + len(cols)))
            self.layer_cols.append(cols)
            self.layer_shift.append(self.shift[r, cols])
            eid += len(cols)
        self.n_edges_base = eid
        self.H = H

        # Systematic encoder: H = [Hs | Hp], p = Hp^-1 Hs s  (mod 2)
        Hs, Hp = H[:, : self.K], H[:, self.K :]
        self.Gp = (gf2_inv(Hp).astype(np.int64) @ Hs.astype(np.int64)) % 2  # (M, K)

    def encode(self, info_bits):
        """info_bits: (B, K) 0/1 array -> codewords (B, N) incl. punctured bits."""
        info_bits = np.asarray(info_bits, dtype=np.int64)
        parity = (info_bits @ self.Gp.T) % 2
        return np.concatenate([info_bits, parity], axis=1).astype(np.uint8)

    def syndrome_ok(self, cw):
        return np.all((cw.astype(np.int64) @ self.H.T.astype(np.int64)) % 2 == 0, axis=1)

    def degree_profile(self):
        return {
            "check_degrees": [len(c) for c in self.layer_cols],
            "var_degrees": self.H.sum(0).reshape(-1, self.Z)[:, 0].tolist(),
        }

    def __repr__(self):
        return (f"BG2Code(Z={self.Z}, i_LS={self.i_ls}, m={self.m}, K={self.K}, "
                f"N={self.N}, N_tx={self.N_tx}, R={self.rate:.4f}, "
                f"base edges={self.n_edges_base})")
