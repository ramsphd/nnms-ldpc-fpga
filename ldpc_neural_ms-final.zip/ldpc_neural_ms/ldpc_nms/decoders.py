"""Layered decoders for BG2Code: BP, MS, NMS, OMS and neural NMS (float), plus a
bit-exact fixed-point layered (neural) NMS model that serves as the golden reference
for the HLS/RTL implementation.

LLR convention: L > 0 means bit 0 (BPSK: bit 0 -> +1).
Layered schedule: one layer = one base-graph row = Z parallel check nodes.
Within a layer every variable node appears at most once (QC structure), so all Z
checks of a layer can be updated in parallel, exactly as the hardware will do.
"""
import numpy as np
import torch
import torch.nn as nn


def _min_excl(mag):
    """For each edge, the minimum magnitude over the OTHER edges of its check."""
    two = torch.topk(mag, 2, dim=-1, largest=False)
    min1, min2 = two.values[..., :1], two.values[..., 1:2]
    is_min = torch.arange(mag.shape[-1], device=mag.device) == two.indices[..., :1]
    return torch.where(is_min, min2, min1)


def _sign(x):
    return torch.where(x >= 0, torch.ones_like(x), -torch.ones_like(x))


def _phi(x):
    x = x.clamp(1e-7, 30.0)
    return -torch.log(torch.tanh(x / 2))


class LayeredDecoder(nn.Module):
    """kind: 'bp' | 'ms' | 'nms' | 'oms' | 'neural'
    share (neural only): 'edge'  -> one weight per (iteration, base-graph edge)
                         'layer' -> one weight per (iteration, layer)
                         'iter'  -> one weight per iteration
    """

    def __init__(self, code, iters=10, kind="nms", alpha=0.75, beta=0.5,
                 share="edge", init=0.75):
        super().__init__()
        self.code, self.T, self.kind = code, iters, kind
        self.alpha, self.beta, self.share = alpha, beta, share
        for r, idx in enumerate(code.layer_idx):
            self.register_buffer(f"idx{r}", torch.as_tensor(idx))
        self.n_layers = len(code.layer_idx)
        if kind == "neural":
            if share == "edge":
                pid = code.layer_eid
                P = code.n_edges_base
            elif share == "layer":
                pid = [np.full(len(e), r) for r, e in enumerate(code.layer_eid)]
                P = self.n_layers
            elif share == "iter":
                pid = [np.zeros(len(e), dtype=int) for e in code.layer_eid]
                P = 1
            else:
                raise ValueError(share)
            for r, p in enumerate(pid):
                self.register_buffer(f"pid{r}", torch.as_tensor(p, dtype=torch.long))
            self.w = nn.Parameter(torch.full((iters, P), float(init)))
        self.weight_quant = None  # set to e.g. 16 to quantize weights to k/16 (STE)

    def weights(self):
        w = self.w
        if self.weight_quant:
            q = self.weight_quant
            wq = torch.clamp(torch.round(w * q), 0, q) / q
            w = w + (wq - w).detach()  # straight-through estimator
        return w

    def _cn(self, Q, t, r, W=None):
        sgn = _sign(Q)
        sgn_excl = sgn.prod(-1, keepdim=True) * sgn
        mag = Q.abs()
        if self.kind == "bp":
            ph = _phi(mag)
            return sgn_excl * _phi(ph.sum(-1, keepdim=True) - ph)
        m = _min_excl(mag)
        if self.kind == "ms":
            return sgn_excl * m
        if self.kind == "nms":
            return sgn_excl * self.alpha * m
        if self.kind == "oms":
            return sgn_excl * torch.relu(m - self.beta)
        if self.kind == "neural":
            w = W[t, getattr(self, f"pid{r}")]  # (d,)
            return sgn_excl * w * m
        raise ValueError(self.kind)

    def forward(self, llr, return_all=False):
        """llr: (B, N) channel LLRs (punctured positions = 0). Returns posterior LLRs."""
        B = llr.shape[0]
        L = llr
        R = [torch.zeros(B, self.code.Z, getattr(self, f"idx{r}").shape[1],
                         dtype=llr.dtype, device=llr.device) for r in range(self.n_layers)]
        W = self.weights() if self.kind == "neural" else None
        outs = []
        for t in range(self.T):
            for r in range(self.n_layers):
                idx = getattr(self, f"idx{r}")
                Q = L[:, idx] - R[r]
                R[r] = self._cn(Q, t, r, W)
                L = L.scatter(1, idx.reshape(1, -1).expand(B, -1), (Q + R[r]).reshape(B, -1))
            if return_all:
                outs.append(L)
        return outs if return_all else L


# ------------------------------------------------- fixed-point-aware training --
def _ste(x, q):
    return x + (q - x).detach()


class FixedPointAwareNeuralNMS(LayeredDecoder):
    """Neural NMS whose forward pass reproduces FixedPointNMS exactly (integer
    channel quantization, saturation, (W*min)>>w_frac with floor or round), with
    straight-through gradients, so weights are trained for the real hardware
    arithmetic. Input: received samples y (like FixedPointNMS with use_y=True)."""

    def __init__(self, code, iters=10, share="edge", q_ch=6, q_L=8, q_R=6,
                 scale=8.0, w_frac=4, round_mode="floor", init=0.75):
        super().__init__(code, iters, "neural", share=share, init=init)
        self.q_ch, self.q_L, self.q_R, self.scale = q_ch, q_L, q_R, scale
        self.w_frac, self.round_mode = w_frac, round_mode
        self.weight_quant = 1 << w_frac

    @staticmethod
    def _sat(x, bits):
        lim = float((1 << (bits - 1)) - 1)
        return x.clamp(-lim, lim)

    def forward(self, y, return_all=False):
        B = y.shape[0]
        L = self._sat(self._sat(_ste(y * self.scale, torch.round(y * self.scale)), self.q_ch), self.q_L)
        R = [torch.zeros(B, self.code.Z, getattr(self, f"idx{r}").shape[1]) for r in range(self.n_layers)]
        W = self.weights()
        lim_R = float((1 << (self.q_R - 1)) - 1)
        off = 0.5 if self.round_mode == "round" else 0.0
        outs = []
        for t in range(self.T):
            for r in range(self.n_layers):
                idx = getattr(self, f"idx{r}")
                Q = self._sat(L[:, idx] - R[r], self.q_L)
                sgn = _sign(Q)
                sgn_excl = sgn.prod(-1, keepdim=True) * sgn
                m = _min_excl(Q.abs())
                w = W[t, getattr(self, f"pid{r}")]
                prod = w * m + off
                mag = _ste(prod, torch.floor(prod)).clamp(max=lim_R)
                R[r] = sgn_excl * mag
                L = L.scatter(1, idx.reshape(1, -1).expand(B, -1),
                              self._sat(Q + R[r], self.q_L).reshape(B, -1))
            if return_all:
                outs.append(L)
        return outs if return_all else L


# ---------------------------------------------------------------- fixed point --
class FixedPointNMS:
    """Bit-exact integer model of the layered (neural) normalized min-sum decoder.

    q_ch : bits of the quantized channel LLR (sign + magnitude, symmetric)
    q_L  : bits of the posterior LLR memory (L-RAM)
    q_R  : bits of the check-to-variable message memory (R-RAM)
    scale: channel LLR scaling before rounding (LLR_int = round(scale * LLR))
    w_int: integer weights, shape (T, n_layers, max_deg) or a scalar, applied as
           (w_int * min) >> w_frac   (w_frac = 4 -> weights k/16, a shift-add in HW)
    """

    def __init__(self, code, iters=10, q_ch=6, q_L=8, q_R=6, scale=2.0,
                 w_int=12, w_frac=4, round_mode="floor"):
        self.code, self.T = code, iters
        self.q_ch, self.q_L, self.q_R, self.scale = q_ch, q_L, q_R, scale
        self.w_frac, self.round_mode = w_frac, round_mode
        self.idx = [torch.as_tensor(i) for i in code.layer_idx]
        nl = len(self.idx)
        dmax = max(i.shape[1] for i in self.idx)
        if np.isscalar(w_int):
            w_int = np.full((iters, nl, dmax), int(w_int))
        self.w_int = torch.as_tensor(np.asarray(w_int), dtype=torch.int32)

    @staticmethod
    def _sat(x, bits):
        lim = (1 << (bits - 1)) - 1
        return x.clamp(-lim, lim)

    def quantize_channel(self, llr):
        return self._sat(torch.round(llr * self.scale).to(torch.int32), self.q_ch)

    def decode_int(self, Lq, early_stop=False, return_iters=False):
        """Lq: (B, N) int32 quantized channel LLRs. Returns final integer posteriors.

        early_stop: on-the-fly syndrome check exactly as the hardware does it. While a
        layer is read (phase A), the parity of the hard decisions of the posteriors it
        reads is computed per check; if no check of any layer failed during a whole
        iteration, the frame stops after that iteration (L and R frozen)."""
        B, Z = Lq.shape[0], self.code.Z
        L = self._sat(Lq.clone(), self.q_L)
        R = [torch.zeros(B, Z, i.shape[1], dtype=torch.int32) for i in self.idx]
        half = (1 << (self.w_frac - 1)) if self.round_mode == "round" else 0
        active = torch.ones(B, dtype=torch.bool)
        iters_used = torch.zeros(B, dtype=torch.int32)
        for t in range(self.T):
            if early_stop and not bool(active.any()):
                break
            iters_used += active.to(torch.int32)
            fail = torch.zeros(B, dtype=torch.bool)
            for r, idx in enumerate(self.idx):
                d = idx.shape[1]
                Lr = L[:, idx]
                if early_stop:
                    fail |= ((Lr < 0).sum(-1) % 2 != 0).any(-1)
                Q = self._sat(Lr - R[r], self.q_L)
                sgn = torch.where(Q >= 0, 1, -1).to(torch.int32)
                sgn_excl = (sgn.prod(-1, keepdim=True) * sgn).to(torch.int32)
                mag = Q.abs()
                m = _min_excl(mag)
                w = self.w_int[t, r, :d]
                mag_out = (w * m + half) >> self.w_frac
                lim = (1 << (self.q_R - 1)) - 1
                R_new = (sgn_excl * mag_out.clamp(max=lim)).to(torch.int32)
                L_new = L.scatter(1, idx.reshape(1, -1).expand(B, -1),
                                  self._sat(Q + R_new, self.q_L).reshape(B, -1))
                if early_stop:
                    R[r] = torch.where(active[:, None, None], R_new, R[r])
                    L = torch.where(active[:, None], L_new, L)
                else:
                    R[r], L = R_new, L_new
            if early_stop:
                active &= fail
        return (L, iters_used) if return_iters else L

    def __call__(self, llr):
        return self.decode_int(self.quantize_channel(llr)).to(torch.float32)


def neural_to_int_weights(dec, w_frac=4):
    """Export trained neural weights to the (T, n_layers, max_deg) integer table."""
    q = 1 << w_frac
    W = dec.weights().detach().cpu().numpy()
    nl = dec.n_layers
    dmax = max(getattr(dec, f"idx{r}").shape[1] for r in range(nl))
    out = np.zeros((dec.T, nl, dmax), dtype=np.int32)
    for r in range(nl):
        pid = getattr(dec, f"pid{r}").cpu().numpy()
        out[:, r, : len(pid)] = np.clip(np.round(W[:, pid] * q), 0, q)
    return out
