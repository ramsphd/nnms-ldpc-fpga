"""BPSK over AWGN for BG2Code, with puncturing of the first 2Z bits, and a
Monte-Carlo BER/FER simulator."""
import time
import numpy as np
import torch


def ebn0_to_sigma(ebn0_db, rate):
    return np.sqrt(1.0 / (2.0 * rate * 10 ** (np.asarray(ebn0_db) / 10.0)))


def make_batch(code, B, ebn0_db, rng, random_info=True):
    """Returns info bits (B,K), codewords (B,N), received y (B,N) and LLRs (B,N).
    ebn0_db can be a scalar or an array of length B. Punctured positions: y = 0, LLR = 0."""
    info = rng.integers(0, 2, (B, code.K)) if random_info else np.zeros((B, code.K), int)
    cw = code.encode(info)
    sigma = ebn0_to_sigma(np.broadcast_to(ebn0_db, (B,)), code.rate)[:, None]
    x = 1.0 - 2.0 * cw
    y = x + sigma * rng.standard_normal(cw.shape)
    y[:, : code.n_punct] = 0.0
    llr = 2.0 * y / sigma**2
    f = lambda a: torch.as_tensor(a, dtype=torch.float32)
    return info, cw, f(y), f(llr)


@torch.no_grad()
def simulate(code, decode, ebn0_list, batch=1000, min_frame_err=100,
             max_frames=200_000, seed=1, use_y=False, verbose=True):
    """decode: callable(tensor (B,N)) -> posterior LLR tensor (B,N).
    use_y=True passes the received samples instead of LLRs (for scale-invariant
    fixed-point min-sum decoders that need no noise-variance estimate)."""
    rng = np.random.default_rng(seed)
    rows = []
    for eb in ebn0_list:
        fe = be = nf = 0
        t0 = time.time()
        while fe < min_frame_err and nf < max_frames:
            info, cw, y, llr = make_batch(code, batch, eb, rng)
            L = decode(y if use_y else llr)
            hard = (L[:, : code.K] < 0).numpy().astype(np.uint8)
            err = hard != info
            be += int(err.sum())
            fe += int(err.any(1).sum())
            nf += batch
        ber, fer = be / (nf * code.K), fe / nf
        rows.append(dict(ebn0=float(eb), ber=ber, fer=fer, frames=nf, frame_errors=fe))
        if verbose:
            print(f"  Eb/N0={eb:5.2f} dB  BER={ber:.3e}  FER={fer:.3e}  "
                  f"({fe} fe / {nf} frames, {time.time()-t0:.1f}s)", flush=True)
    return rows
