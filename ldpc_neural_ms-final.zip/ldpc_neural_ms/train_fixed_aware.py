"""Stage 3: fine-tune neural NMS weights through the exact fixed-point arithmetic
(FixedPointAwareNeuralNMS), starting from the float-trained weights.

Writes to --out: decoder_fx.pt, weights_int.npy, weights_int.h, train_log.csv,
and checks bit-exactness against the integer golden model FixedPointNMS.
"""
import argparse, csv, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from ldpc_nms.code5g import BG2Code
from ldpc_nms.decoders import FixedPointAwareNeuralNMS, FixedPointNMS, neural_to_int_weights
from ldpc_nms.channel import make_batch
from train_neural import write_header


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Z", type=int, default=16)
    ap.add_argument("--m", type=int, default=12)
    ap.add_argument("--iters", type=int, default=10)
    ap.add_argument("--share", default="edge")
    ap.add_argument("--init", default="results/neural_edge/decoder.pt")
    ap.add_argument("--q", default="6,7,5")
    ap.add_argument("--scale", type=float, default=8.0)
    ap.add_argument("--round_mode", default="floor", choices=["floor", "round"])
    ap.add_argument("--steps", type=int, default=600)
    ap.add_argument("--batch", type=int, default=500)
    ap.add_argument("--lr", type=float, default=0.003)
    ap.add_argument("--ebn0_lo", type=float, default=1.5)
    ap.add_argument("--ebn0_hi", type=float, default=3.5)
    ap.add_argument("--seed", type=int, default=2)
    ap.add_argument("--out", default="results/neural_edge_fx")
    a = ap.parse_args()

    torch.manual_seed(a.seed)
    rng = np.random.default_rng(a.seed)
    q_ch, q_L, q_R = (int(x) for x in a.q.split(","))
    code = BG2Code(a.Z, a.m)
    dec = FixedPointAwareNeuralNMS(code, a.iters, a.share, q_ch, q_L, q_R, a.scale,
                                   round_mode=a.round_mode)
    if a.init:
        sd = torch.load(a.init)
        dec.w.data.copy_(sd["w"])
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    opt = torch.optim.Adam(dec.parameters(), lr=a.lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.steps)
    log, t0 = [], time.time()
    llr_gain = 2.0 / a.scale  # integer posterior -> approx. LLR scale for the loss
    for s in range(a.steps):
        eb = rng.uniform(a.ebn0_lo, a.ebn0_hi, size=a.batch)
        _, cw, y, _ = make_batch(code, a.batch, eb, rng)
        outs = dec(y, return_all=True)
        T = len(outs)
        cw_t = torch.as_tensor(cw, dtype=torch.float32)
        loss = sum((t + 1) * F.binary_cross_entropy_with_logits(-o * llr_gain, cw_t)
                   for t, o in enumerate(outs)) / sum(range(1, T + 1))
        opt.zero_grad(); loss.backward(); opt.step(); sched.step()
        with torch.no_grad():
            dec.w.clamp_(0.0, 1.0)
        log.append(dict(step=s, loss=loss.item()))
        if s % 50 == 0 or s == a.steps - 1:
            print(f"step {s:4d} loss {loss.item():.5f} ({time.time()-t0:.0f}s)", flush=True)

    torch.save(dec.state_dict(), out / "decoder_fx.pt")
    W = neural_to_int_weights(dec, 4)
    np.save(out / "weights_int.npy", W)
    write_header(out / "weights_int.h", W, code, 4)
    with open(out / "train_log.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["step", "loss"]); w.writeheader(); w.writerows(log)

    # Bit-exactness check against the integer golden model
    gold = FixedPointNMS(code, a.iters, q_ch, q_L, q_R, a.scale, w_int=W, round_mode=a.round_mode)
    _, _, y, _ = make_batch(code, 2000, 2.5, np.random.default_rng(123))
    with torch.no_grad():
        a_out = dec(y)
    g_out = gold.decode_int(gold.quantize_channel(y)).float()
    print("bit-exact vs FixedPointNMS:", bool(torch.equal(a_out, g_out)),
          "| max |diff| =", float((a_out - g_out).abs().max()))
    print("saved", out)


if __name__ == "__main__":
    torch.set_num_threads(2)
    main()
