// Quantized neural normalized min-sum layered LDPC decoder -- version 2
// 5G NR BG2-derived code, Z = 16, K = 160, N_tx = 320, R = 1/2
// Target: Vivado HLS 2019.2, Zynq-7020 (ZedBoard)
//
// Changes from version 1 (arithmetic is identical, bit-exact with FixedPointNMS):
//   * phases A and B of a layer run in ONE pipelined loop (one pipeline fill per layer)
//   * no Q buffer: phase B re-reads L and R and recomputes Q with the same shifter
//   * no R-clearing loop: R is read as 0 in the first iteration
//   * board top-level nnms_axi with 32-bit word arrays on AXI-Lite (ARM reads/writes directly)
#ifndef NNMS2_H
#define NNMS2_H

#include <ap_int.h>

#define NNMS_Z      16
#define NNMS_LOGZ   4
#define NNMS_NL     12
#define NNMS_NC     22
#define NNMS_KB     10
#define NNMS_NP     2
#define NNMS_NTX    (NNMS_NC - NNMS_NP)   // 20 transmitted column blocks
#define NNMS_TMAX   10

#define NNMS_QCH    6
#define NNMS_QL     7
#define NNMS_QR     5
#define NNMS_WFRAC  4

#define NNMS_YWORDS (NNMS_NTX * NNMS_Z * NNMS_QCH / 32)   // 60 words of input
#define NNMS_BWORDS (NNMS_KB * NNMS_Z / 32)               // 5 words of decoded bits

typedef ap_int<NNMS_QCH>   ch_t;
typedef ap_int<NNMS_QL>    lval_t;
typedef ap_int<NNMS_QR>    rval_t;
typedef ap_uint<NNMS_QL-1> mag_t;
typedef ap_uint<5>         w_t;

typedef ap_uint<NNMS_Z * NNMS_QL>  lword_t;   // 112 b
typedef ap_uint<NNMS_Z * NNMS_QR>  rword_t;   // 80 b
typedef ap_uint<NNMS_Z * NNMS_QCH> chword_t;  // 96 b

// Decoder core (sub-function; its latency is reported separately by HLS).
//   y_in  : 20 transmitted column blocks (columns 2..21), lane j = variable c*Z + j
//   L_out : final posteriors of all 22 column blocks
void nnms_core(const chword_t y_in[NNMS_NTX], lword_t L_out[NNMS_NC],
               ap_uint<4> max_iter, bool early_stop, ap_uint<4> *iters_used);

// Board top-level: everything on one AXI-Lite slave (bundle "ctrl").
//   y_words[3c+i]  = bits 32i..32i+31 of input block c (6-bit samples, lane j at bits 6j..6j+5)
//   bits_words[w]  = decoded bit of information variable 32w+b at bit b (1 = bit one)
void nnms_axi(const ap_uint<32> y_words[NNMS_YWORDS], ap_uint<32> bits_words[NNMS_BWORDS],
              ap_uint<4> max_iter, bool early_stop, ap_uint<4> *iters_used);

#endif
