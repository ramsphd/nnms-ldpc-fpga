// Quantized neural normalized min-sum layered LDPC decoder, version 2 -- Vivado HLS 2019.2
//
// One pipelined loop per layer with 2*d_r steps:
//   steps 0 .. d_r-1    (phase A): read L block and R block, cyclic shift, Q = L - R,
//                                   track min1/min2/idx, sign XOR, syndrome parity
//   steps d_r .. 2d_r-1 (phase B): read the same blocks again, recompute Q, weighted min,
//                                   R_new = sign * min(15, (W*m) >> 4), L = Q + R_new,
//                                   inverse shift, write L block and R block
// Within one layer every column block appears once, so the L and R memories carry no
// read-after-write dependence between steps of the same loop (DEPENDENCE inter false).
// Bit-exact with FixedPointNMS (Python): q_ch=6, q_L=7, q_R=5, floor rounding.

#include "nnms2.h"
#include "nnms_tables.h"

static lval_t sat_l(ap_int<9> x) {
#pragma HLS INLINE
    const int lim = (1 << (NNMS_QL - 1)) - 1;
    if (x > lim) return (lval_t)lim;
    if (x < -lim) return (lval_t)(-lim);
    return (lval_t)x;
}

void nnms_core(const chword_t y_in[NNMS_NTX], lword_t L_out[NNMS_NC],
               ap_uint<4> max_iter, bool early_stop, ap_uint<4> *iters_used) {
#pragma HLS INLINE off
    lword_t Lmem[NNMS_NC];
    rword_t Rmem[NNMS_E];

INIT_L:
    for (int c = 0; c < NNMS_NC; c++) {
#pragma HLS PIPELINE II=1
        lword_t w = 0;
        if (c >= NNMS_NP) {
            chword_t in = y_in[c - NNMS_NP];
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                ch_t v = in.range(NNMS_QCH * j + NNMS_QCH - 1, NNMS_QCH * j);
                lval_t lv = v;
                w.range(NNMS_QL * j + NNMS_QL - 1, NNMS_QL * j) = lv;
            }
        }
        Lmem[c] = w;
    }

    ap_uint<4> it = 0;
ITER:
    for (int t = 0; t < NNMS_TMAX; t++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=10 avg=5
        if (t >= max_iter) break;
        const bool first = (t == 0);
        bool fail = false;

    LAYER:
        for (int r = 0; r < NNMS_NL; r++) {
            mag_t      min1[NNMS_Z], min2[NNMS_Z];
            ap_uint<4> idx[NNMS_Z];
            ap_uint<1> sp[NNMS_Z], par[NNMS_Z];
#pragma HLS ARRAY_PARTITION variable=min1 complete
#pragma HLS ARRAY_PARTITION variable=min2 complete
#pragma HLS ARRAY_PARTITION variable=idx  complete
#pragma HLS ARRAY_PARTITION variable=sp   complete
#pragma HLS ARRAY_PARTITION variable=par  complete
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                min1[j] = (1 << (NNMS_QL - 1)) - 1;
                min2[j] = (1 << (NNMS_QL - 1)) - 1;
                idx[j] = 0; sp[j] = 0; par[j] = 0;
            }
            const int st = LAYER_START[r];
            const int d  = LAYER_DEG[r];

        STEP:
            for (int k = 0; k < 2 * d; k++) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=8 max=20 avg=13
#pragma HLS DEPENDENCE variable=Lmem inter false
#pragma HLS DEPENDENCE variable=Rmem inter false
                const bool phB = (k >= d);
                const ap_uint<4> kk = phB ? (k - d) : k;
                const int e = st + kk;
                const ap_uint<5> c = EDGE_COL[e];
                const ap_uint<NNMS_LOGZ> s = EDGE_SHIFT[e];
                const w_t wt = W_ROM[t][e];
                lword_t lw = Lmem[c];
                rword_t rw = Rmem[e];

                lval_t lane[NNMS_Z];
#pragma HLS ARRAY_PARTITION variable=lane complete
                for (int i = 0; i < NNMS_Z; i++) {
#pragma HLS UNROLL
                    lane[i] = lw.range(NNMS_QL * i + NNMS_QL - 1, NNMS_QL * i);
                }
                lval_t ln[NNMS_Z];
#pragma HLS ARRAY_PARTITION variable=ln complete
                rword_t rw_new = 0;
                for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                    ap_uint<NNMS_LOGZ> src = (ap_uint<NNMS_LOGZ>)(j + s);
                    lval_t lv = lane[src];
                    rval_t rv = first ? (rval_t)0
                                      : (rval_t)rw.range(NNMS_QR * j + NNMS_QR - 1, NNMS_QR * j);
                    lval_t q = sat_l((ap_int<9>)lv - (ap_int<9>)rv);
                    ap_uint<1> sg = (q < 0);
                    mag_t m = sg ? (mag_t)(-q) : (mag_t)q;
                    if (!phB) {
                        par[j] ^= (ap_uint<1>)(lv < 0);
                        sp[j] ^= sg;
                        if (m < min1[j]) { min2[j] = min1[j]; min1[j] = m; idx[j] = kk; }
                        else if (m < min2[j]) { min2[j] = m; }
                        ln[j] = 0;
                    } else {
                        mag_t me = (idx[j] == kk) ? min2[j] : min1[j];
                        ap_uint<11> prod = wt * me;
                        ap_uint<7> mg = prod >> NNMS_WFRAC;
                        if (mg > 15) mg = 15;
                        rval_t rn = (sp[j] ^ sg) ? (rval_t)(-(ap_int<6>)mg) : (rval_t)mg;
                        rw_new.range(NNMS_QR * j + NNMS_QR - 1, NNMS_QR * j) = rn;
                        ln[j] = sat_l((ap_int<9>)q + (ap_int<9>)rn);
                    }
                }
                if (phB) {
                    lword_t lw_new = 0;
                    for (int i = 0; i < NNMS_Z; i++) {
#pragma HLS UNROLL
                        ap_uint<NNMS_LOGZ> from = (ap_uint<NNMS_LOGZ>)(i - s);
                        lw_new.range(NNMS_QL * i + NNMS_QL - 1, NNMS_QL * i) = ln[from];
                    }
                    Rmem[e] = rw_new;
                    Lmem[c] = lw_new;
                }
            }

            ap_uint<1> any = 0;
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                any |= par[j];
            }
            if (any) fail = true;
        }
        it = t + 1;
        if (early_stop && !fail) break;
    }
    *iters_used = it;

OUT_L:
    for (int c = 0; c < NNMS_NC; c++) {
#pragma HLS PIPELINE II=1
        L_out[c] = Lmem[c];
    }
}

void nnms_axi(const ap_uint<32> y_words[NNMS_YWORDS], ap_uint<32> bits_words[NNMS_BWORDS],
              ap_uint<4> max_iter, bool early_stop, ap_uint<4> *iters_used) {
#pragma HLS INTERFACE s_axilite port=return     bundle=ctrl
#pragma HLS INTERFACE s_axilite port=y_words    bundle=ctrl
#pragma HLS INTERFACE s_axilite port=bits_words bundle=ctrl
#pragma HLS INTERFACE s_axilite port=max_iter   bundle=ctrl
#pragma HLS INTERFACE s_axilite port=early_stop bundle=ctrl
#pragma HLS INTERFACE s_axilite port=iters_used bundle=ctrl

    chword_t yb[NNMS_NTX];
    lword_t  Lf[NNMS_NC];

UNPACK:
    for (int c = 0; c < NNMS_NTX; c++) {
        chword_t b = 0;
        for (int i = 0; i < 3; i++) {
#pragma HLS PIPELINE II=1
            b.range(32 * i + 31, 32 * i) = y_words[3 * c + i];
        }
        yb[c] = b;
    }

    nnms_core(yb, Lf, max_iter, early_stop, iters_used);

PACK:
    for (int w = 0; w < NNMS_BWORDS; w++) {
#pragma HLS PIPELINE II=1
        ap_uint<32> o = 0;
        for (int h = 0; h < 2; h++) {
            lword_t blk = Lf[2 * w + h];
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                lval_t v = blk.range(NNMS_QL * j + NNMS_QL - 1, NNMS_QL * j);
                o[16 * h + j] = (v < 0);
            }
        }
        bits_words[w] = o;
    }
}
