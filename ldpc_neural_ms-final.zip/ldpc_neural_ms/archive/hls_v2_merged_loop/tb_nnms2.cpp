// C / RTL testbench for version 2.
//   Test 1 (C only)  : nnms_core, all 352 posteriors vs the Python golden model
//   Test 2 (C + RTL) : nnms_axi top, 160 decoded bits and iteration count vs golden
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "nnms2.h"

typedef std::vector<std::vector<int> > rows_t;

static bool read_rows(const char *path, rows_t &rows) {
    std::ifstream f(path);
    if (!f) { std::printf("cannot open %s\n", path); return false; }
    std::string line;
    while (std::getline(f, line)) {
        std::istringstream ss(line);
        std::vector<int> v; int x;
        while (ss >> x) v.push_back(x);
        if (!v.empty()) rows.push_back(v);
    }
    return true;
}

static void pack_blocks(const std::vector<int> &y, chword_t blk[NNMS_NTX]) {
    for (int c = 0; c < NNMS_NTX; c++) {
        chword_t w = 0;
        for (int j = 0; j < NNMS_Z; j++) {
            ch_t v = y[c * NNMS_Z + j];
            w.range(NNMS_QCH * j + NNMS_QCH - 1, NNMS_QCH * j) = v;
        }
        blk[c] = w;
    }
}

static int test_core(const rows_t &y, const rows_t &L, const rows_t *it, bool es) {
    int bad = 0;
    for (size_t f = 0; f < y.size(); f++) {
        chword_t blk[NNMS_NTX]; lword_t Lo[NNMS_NC]; ap_uint<4> n;
        pack_blocks(y[f], blk);
        nnms_core(blk, Lo, 10, es, &n);
        bool ok = !it || (int)n == (*it)[f][0];
        for (int c = 0; c < NNMS_NC && ok; c++)
            for (int j = 0; j < NNMS_Z; j++) {
                lval_t v = Lo[c].range(NNMS_QL * j + NNMS_QL - 1, NNMS_QL * j);
                if ((int)v != L[f][c * NNMS_Z + j]) { ok = false; break; }
            }
        if (!ok) bad++;
    }
    return bad;
}

static int test_top(const rows_t &y, const rows_t &L, const rows_t *it, bool es, long *sum) {
    int bad = 0;
    for (size_t f = 0; f < y.size(); f++) {
        chword_t blk[NNMS_NTX];
        pack_blocks(y[f], blk);
        ap_uint<32> yw[NNMS_YWORDS], bw[NNMS_BWORDS]; ap_uint<4> n;
        for (int c = 0; c < NNMS_NTX; c++)
            for (int i = 0; i < 3; i++) yw[3 * c + i] = blk[c].range(32 * i + 31, 32 * i);
        nnms_axi(yw, bw, 10, es, &n);
        *sum += n;
        bool ok = !it || (int)n == (*it)[f][0];
        for (int v = 0; v < NNMS_KB * NNMS_Z && ok; v++)
            if ((int)bw[v / 32][v % 32] != (L[f][v] < 0)) ok = false;
        if (!ok) bad++;
    }
    return bad;
}

int main() {
    rows_t y, L, Let, it;
    if (!read_rows("golden/y_in.txt", y) || !read_rows("golden/L_out.txt", L) ||
        !read_rows("golden/L_out_et.txt", Let) || !read_rows("golden/iters_et.txt", it))
        return 1;
    int e1 = test_core(y, L, 0, false);
    int e2 = test_core(y, Let, &it, true);
    std::printf("core, 10 iterations : %zu frames, %d mismatching (all 352 posteriors)\n", y.size(), e1);
    std::printf("core, early stop    : %zu frames, %d mismatching (posteriors + iterations)\n", y.size(), e2);
    long s1 = 0, s2 = 0;
    int e3 = test_top(y, L, 0, false, &s1);
    int e4 = test_top(y, Let, &it, true, &s2);
    std::printf("top,  10 iterations : %zu frames, %d mismatching (160 bits)\n", y.size(), e3);
    std::printf("top,  early stop    : %zu frames, %d mismatching (bits + iterations), avg %.2f iterations\n",
                y.size(), e4, (double)s2 / y.size());
    if (e1 || e2 || e3 || e4) { std::printf("FAIL\n"); return 1; }
    std::printf("PASS: version 2 is bit-exact with the Python golden model\n");
    return 0;
}
