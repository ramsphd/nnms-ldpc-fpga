// Quantized neural normalized min-sum layered LDPC decoder -- Vivado HLS 2019.2
//
// Architecture: edge-serial, check-parallel layered decoding.
//   * 16 lanes = the 16 lifted checks of one base-graph row, processed together.
//   * One base-graph edge (one 16-lane block) per clock.
//   * Two phases per layer:
//       A (read):  L block -> cyclic shift -> Q = L - R -> running min1/min2/idx/sign,
//                  parity of hard decisions for early termination; Q kept in Qbuf.
//       B (write): R_new = sign * min(15, (W * m_excl) >> 4); L_new = Q + R_new
//                  -> inverse shift -> L block; R_new -> R memory.
//   * Weights W[t][e] from ROM: per iteration and per base-graph edge (neural NMS).
//
// Bit-exact with FixedPointNMS (Python) for q_ch=6, q_L=7, q_R=5, floor rounding.

#include "nnms.h"
#include "nnms_tables.h"

static lval_t sat_l(ap_int<9> x) {
#pragma HLS INLINE
    const int lim = (1 << (NNMS_QL - 1)) - 1;   // 63
    if (x > lim) return (lval_t)lim;
    if (x < -lim) return (lval_t)(-lim);
    return (lval_t)x;
}

void nnms_decode(const chword_t y_in[NNMS_NTX],
                 bword_t bits_out[NNMS_KB],
                 lword_t L_dbg[NNMS_NC],
                 ap_uint<4> max_iter,
                 bool early_stop,
                 ap_uint<4> *iters_used) {
#pragma HLS INTERFACE s_axilite port=return     bundle=ctrl
#pragma HLS INTERFACE s_axilite port=max_iter   bundle=ctrl
#pragma HLS INTERFACE s_axilite port=early_stop bundle=ctrl
#pragma HLS INTERFACE s_axilite port=iters_used bundle=ctrl
#pragma HLS INTERFACE bram port=y_in
#pragma HLS INTERFACE bram port=bits_out
#pragma HLS INTERFACE bram port=L_dbg

    lword_t Lmem[NNMS_NC];               // posterior memory: 22 x 112 b
    rword_t Rmem[NNMS_E];                // message memory:   77 x 80 b
    lval_t  Qbuf[NNMS_DMAX][NNMS_Z];     // Q values of the current layer
#pragma HLS ARRAY_PARTITION variable=Qbuf complete dim=2

    // ---------------------------------------------------------------- load
INIT_L:
    for (int c = 0; c < NNMS_NC; c++) {
#pragma HLS PIPELINE II=1
        lword_t w = 0;
        if (c >= NNMS_NP) {
            chword_t in = y_in[c - NNMS_NP];
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                ch_t v = in.range(NNMS_QCH * j + NNMS_QCH - 1, NNMS_QCH * j);
                lval_t lv = v;                              // sign extension 6 -> 7 b
                w.range(NNMS_QL * j + NNMS_QL - 1, NNMS_QL * j) = lv;
            }
        }
        Lmem[c] = w;                                        // punctured blocks = 0
    }
INIT_R:
    for (int e = 0; e < NNMS_E; e++) {
#pragma HLS PIPELINE II=1
        Rmem[e] = 0;
    }

    // ---------------------------------------------------------------- decode
    ap_uint<4> it = 0;
ITER:
    for (int t = 0; t < NNMS_TMAX; t++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=10 avg=5
        if (t >= max_iter) break;
        bool fail = false;

    LAYER:
        for (int r = 0; r < NNMS_NL; r++) {
            mag_t      min1[NNMS_Z], min2[NNMS_Z];
            ap_uint<4> idx[NNMS_Z];
            ap_uint<1> sp[NNMS_Z];       // XOR of sign bits of Q over the layer
            ap_uint<1> par[NNMS_Z];      // XOR of hard decisions of L (syndrome)
#pragma HLS ARRAY_PARTITION variable=min1 complete
#pragma HLS ARRAY_PARTITION variable=min2 complete
#pragma HLS ARRAY_PARTITION variable=idx  complete
#pragma HLS ARRAY_PARTITION variable=sp   complete
#pragma HLS ARRAY_PARTITION variable=par  complete
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                min1[j] = (1 << (NNMS_QL - 1)) - 1;
                min2[j] = (1 << (NNMS_QL - 1)) - 1;
                idx[j] = 0; sp[j] = 0; par[j] = 0;
            }
            const int st = LAYER_START[r];
            const int d  = LAYER_DEG[r];

            // ---- phase A: read, shift, subtract, find minima
        PHASE_A:
            for (int k = 0; k < d; k++) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=4 max=10 avg=6
                const int e = st + k;
                const ap_uint<5> c = EDGE_COL[e];
                const ap_uint<NNMS_LOGZ> s = EDGE_SHIFT[e];
                lword_t lw = Lmem[c];
                rword_t rw = Rmem[e];
                lval_t lane[NNMS_Z];
#pragma HLS ARRAY_PARTITION variable=lane complete
                for (int i = 0; i < NNMS_Z; i++) {
#pragma HLS UNROLL
                    lane[i] = lw.range(NNMS_QL * i + NNMS_QL - 1, NNMS_QL * i);
                }
                for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                    ap_uint<NNMS_LOGZ> src = (ap_uint<NNMS_LOGZ>)(j + s);   // (j + s) mod Z
                    lval_t lv = lane[src];                                    // cyclic shift
                    rval_t rv = rw.range(NNMS_QR * j + NNMS_QR - 1, NNMS_QR * j);
                    par[j] ^= (ap_uint<1>)(lv < 0);
                    lval_t q = sat_l((ap_int<9>)lv - (ap_int<9>)rv);
                    Qbuf[k][j] = q;
                    ap_uint<1> sg = (q < 0);
                    sp[j] ^= sg;
                    mag_t m = sg ? (mag_t)(-q) : (mag_t)q;
                    if (m < min1[j]) { min2[j] = min1[j]; min1[j] = m; idx[j] = k; }
                    else if (m < min2[j]) { min2[j] = m; }
                }
            }

            // ---- phase B: weighted min, update R and L, inverse shift, write back
        PHASE_B:
            for (int k = 0; k < d; k++) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=4 max=10 avg=6
                const int e = st + k;
                const ap_uint<5> c = EDGE_COL[e];
                const ap_uint<NNMS_LOGZ> s = EDGE_SHIFT[e];
                const w_t wt = W_ROM[t][e];
                lval_t ln[NNMS_Z];
#pragma HLS ARRAY_PARTITION variable=ln complete
                rword_t rw_new = 0;
                for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                    lval_t q = Qbuf[k][j];
                    ap_uint<1> sg = (q < 0);
                    mag_t me = (idx[j] == k) ? min2[j] : min1[j];
                    ap_uint<11> prod = wt * me;                        // 5 b x 6 b, no DSP
                    ap_uint<7> mg = prod >> NNMS_WFRAC;                 // floor
                    if (mg > 15) mg = 15;
                    rval_t rn = (sp[j] ^ sg) ? (rval_t)(-(ap_int<6>)mg) : (rval_t)mg;
                    rw_new.range(NNMS_QR * j + NNMS_QR - 1, NNMS_QR * j) = rn;
                    ln[j] = sat_l((ap_int<9>)q + (ap_int<9>)rn);
                }
                lword_t lw_new = 0;
                for (int i = 0; i < NNMS_Z; i++) {
#pragma HLS UNROLL
                    ap_uint<NNMS_LOGZ> from = (ap_uint<NNMS_LOGZ>)(i - s);  // inverse shift
                    lw_new.range(NNMS_QL * i + NNMS_QL - 1, NNMS_QL * i) = ln[from];
                }
                Rmem[e] = rw_new;
                Lmem[c] = lw_new;
            }

            ap_uint<1> any = 0;
            for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
                any |= par[j];
            }
            if (any) fail = true;
        }
        it = t + 1;
        if (early_stop && !fail) break;
    }
    *iters_used = it;

    // ---------------------------------------------------------------- output
OUT_BITS:
    for (int c = 0; c < NNMS_KB; c++) {
#pragma HLS PIPELINE II=1
        lword_t w = Lmem[c];
        bword_t b = 0;
        for (int j = 0; j < NNMS_Z; j++) {
#pragma HLS UNROLL
            lval_t v = w.range(NNMS_QL * j + NNMS_QL - 1, NNMS_QL * j);
            b[j] = (v < 0);
        }
        bits_out[c] = b;
    }
OUT_DBG:
    for (int c = 0; c < NNMS_NC; c++) {
#pragma HLS PIPELINE II=1
        L_dbg[c] = Lmem[c];
    }
}
