# fix_ip_export.tcl -- package the HLS IP despite the Vivado 2019.2 date bug (AMD AR 76960),
# without installing the y2k22 patch and without administrator rights.
#
# Why: Export RTL builds the IP "core_revision" from the date (e.g. 2610241019). That
# number no longer fits a 32-bit integer, so packaging stops with "bad lexical cast".
# This script replaces the revision in the generated run_ippack.tcl with a valid number
# and runs the packaging step again. The RTL itself is not touched.
#
# Usage: in the Vivado HLS 2019.2 Command Prompt, from the hls folder,
#   1. run Export RTL once (it fails, but writes nnms_hls/sol_150MHz/impl/ip/)
#   2. vivado -mode batch -notrace -source fix_ip_export.tcl

set ipdir [file normalize [file join [pwd] nnms_hls sol_150MHz impl ip]]
set f [file join $ipdir run_ippack.tcl]
if {![file exists $f]} {
    puts "ERROR: $f not found. Run Solution > Export RTL once, then run this script again."
    exit 1
}

set fh [open $f r]
set txt [read $fh]
close $fh

set old {core_revision $Revision}
set new {core_revision 1901010000}
if {[string first $old $txt] >= 0} {
    file copy -force $f "$f.orig"
    set txt [string map [list $old $new] $txt]
    set fh [open $f w]
    puts -nonewline $fh $txt
    close $fh
    puts "Patched $f (backup: run_ippack.tcl.orig)"
} elseif {[string first $new $txt] >= 0} {
    puts "run_ippack.tcl already patched"
} else {
    puts "ERROR: could not find 'core_revision \$Revision' in $f"
    exit 1
}

cd $ipdir
puts "Packaging IP in $ipdir ..."
source run_ippack.tcl
puts "Done. Look for the IP zip and component.xml in $ipdir"
