# Vivado HLS 2019.2 -- neural NMS LDPC decoder for the ZedBoard (XC7Z020-CLG484-1)
# Usage (from this folder):   vivado_hls -f run_hls.tcl
# Steps can be switched off below while iterating on the design.
set do_csim   1
set do_csynth 1
set do_cosim  1
set do_export 1

open_project -reset nnms_hls
set_top nnms_decode
add_files nnms_decoder.cpp -cflags "-std=c++0x"
add_files -tb tb_nnms.cpp  -cflags "-std=c++0x"
add_files -tb golden

open_solution -reset "sol_150MHz"
set_part {xc7z020clg484-1}
create_clock -period 6.667 -name default        ;# 150 MHz
set_clock_uncertainty 12.5%

if {$do_csim}   { csim_design -clean }
if {$do_csynth} { csynth_design }
if {$do_cosim}  { cosim_design -rtl verilog -trace_level none }
if {$do_export} { export_design -format ip_catalog -rtl verilog \
                    -description "Quantized neural NMS LDPC decoder, 5G NR BG2 Z=16" \
                    -vendor "kfu.edu.sa" -library "ldpc" -version "1.0" }
exit
