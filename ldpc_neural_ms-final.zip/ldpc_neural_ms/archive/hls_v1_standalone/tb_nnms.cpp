// C testbench for nnms_decode: bit-exact comparison with the Python golden model.
// Run from the folder that contains golden/ (Vivado HLS: add golden/*.txt as -tb files).
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "nnms.h"

static bool read_rows(const char *path, std::vector<std::vector<int> > &rows) {
    std::ifstream f(path);
    if (!f) { std::printf("cannot open %s\n", path); return false; }
    std::string line;
    while (std::getline(f, line)) {
        std::istringstream ss(line);
        std::vector<int> v; int x;
        while (ss >> x) v.push_back(x);
        if (!v.empty()) rows.push_back(v);
    }
    return true;
}

static int run(const std::vector<std::vector<int> > &y, const std::vector<std::vector<int> > &L,
               const std::vector<std::vector<int> > *iters, bool early_stop, long *sum_it) {
    int mismatched_frames = 0;
    for (size_t f = 0; f < y.size(); f++) {
        chword_t in[NNMS_NTX];
        for (int c = 0; c < NNMS_NTX; c++) {
            chword_t w = 0;
            for (int j = 0; j < NNMS_Z; j++) {
                ch_t v = y[f][c * NNMS_Z + j];
                w.range(NNMS_QCH * j + NNMS_QCH - 1, NNMS_QCH * j) = v;
            }
            in[c] = w;
        }
        bword_t bits[NNMS_KB];
        lword_t Ld[NNMS_NC];
        ap_uint<4> it;
        nnms_decode(in, bits, Ld, 10, early_stop, &it);
        *sum_it += it;

        bool bad = false;
        for (int c = 0; c < NNMS_NC && !bad; c++)
            for (int j = 0; j < NNMS_Z; j++) {
                lval_t v = Ld[c].range(NNMS_QL * j + NNMS_QL - 1, NNMS_QL * j);
                if ((int)v != L[f][c * NNMS_Z + j]) { bad = true; break; }
                if (c < NNMS_KB && (int)bits[c][j] != (L[f][c * NNMS_Z + j] < 0)) { bad = true; break; }
            }
        if (iters && (int)it != (*iters)[f][0]) bad = true;
        if (bad) {
            if (mismatched_frames < 5) std::printf("  mismatch in frame %zu\n", f);
            mismatched_frames++;
        }
    }
    return mismatched_frames;
}

int main() {
    std::vector<std::vector<int> > y, L, Let, it;
    if (!read_rows("golden/y_in.txt", y) || !read_rows("golden/L_out.txt", L) ||
        !read_rows("golden/L_out_et.txt", Let) || !read_rows("golden/iters_et.txt", it))
        return 1;
    long s0 = 0, s1 = 0;
    int e0 = run(y, L, 0, false, &s0);
    std::printf("10 iterations      : %zu frames, %d mismatching\n", y.size(), e0);
    int e1 = run(y, Let, &it, true, &s1);
    std::printf("early termination  : %zu frames, %d mismatching, average %.2f iterations\n",
                y.size(), e1, (double)s1 / y.size());
    if (e0 || e1) { std::printf("FAIL\n"); return 1; }
    std::printf("PASS: bit-exact with the Python golden model\n");
    return 0;
}
