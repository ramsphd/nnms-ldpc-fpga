600 frames (200 per Eb/N0 in [1.5,2.5,3.5] dB), seed 2026.
y_in.txt     : 320 ints per line (6-bit quantized y of columns 2..21, lane-major per block)
L_out.txt    : 352 ints per line, final 7-bit posteriors after 10 iterations
L_out_et.txt : same with early termination
iters_et.txt : iterations used with early termination
