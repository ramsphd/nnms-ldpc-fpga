// Quantized neural normalized min-sum (N-NMS) layered LDPC decoder
// 5G NR BG2-derived code, Z = 16, K = 160, N_tx = 320, R = 1/2
// Target: Vivado HLS 2019.2, Zynq-7020 (ZedBoard), 150 MHz
#ifndef NNMS_H
#define NNMS_H

#include <ap_int.h>

// ---- code geometry ---------------------------------------------------------
#define NNMS_Z      16      // lifting size = number of parallel lanes
#define NNMS_LOGZ   4
#define NNMS_NL     12      // layers = base-graph rows
#define NNMS_NC     22      // base-graph columns (10 info + 12 parity)
#define NNMS_KB     10      // information columns
#define NNMS_NP     2       // punctured columns (0 and 1)
#define NNMS_NTX    (NNMS_NC - NNMS_NP)   // transmitted columns = 20
#define NNMS_DMAX   10      // maximum layer degree
#define NNMS_TMAX   10      // maximum iterations (rows of the weight ROM)

// ---- word lengths (must match FixedPointNMS: q_ch=6, q_L=7, q_R=5) ---------
#define NNMS_QCH    6
#define NNMS_QL     7
#define NNMS_QR     5
#define NNMS_WFRAC  4

typedef ap_int<NNMS_QCH>  ch_t;    // quantized channel sample, +-31
typedef ap_int<NNMS_QL>   lval_t;  // posterior / Q value, +-63
typedef ap_int<NNMS_QR>   rval_t;  // check-to-variable message, +-15
typedef ap_uint<NNMS_QL-1> mag_t;  // |Q|, 0..63
typedef ap_uint<5>        w_t;     // weight 0..16 (value/16)

typedef ap_uint<NNMS_Z * NNMS_QL> lword_t;  // one column block of posteriors (112 b)
typedef ap_uint<NNMS_Z * NNMS_QR> rword_t;  // one edge block of messages    (80 b)
typedef ap_uint<NNMS_Z * NNMS_QCH> chword_t; // one column block of input    (96 b)
typedef ap_uint<NNMS_Z>           bword_t;   // one column block of hard bits (16 b)

// Top-level function.
//   y_in     : 20 transmitted column blocks, lane j of block c = received sample of
//              variable node (c+2)*Z + j, 6-bit two's complement packed LSB first
//   bits_out : 10 information column blocks of hard decisions (1 = bit one)
//   L_dbg    : final posteriors of all 22 blocks (verification only; remove in HW)
//   max_iter : 1..10
//   early_stop : on-the-fly syndrome check
//   iters_used : iterations actually run
void nnms_decode(const chword_t y_in[NNMS_NTX],
                 bword_t bits_out[NNMS_KB],
                 lword_t L_dbg[NNMS_NC],
                 ap_uint<4> max_iter,
                 bool early_stop,
                 ap_uint<4> *iters_used);

#endif
