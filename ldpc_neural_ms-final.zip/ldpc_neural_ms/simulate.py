"""BER/FER comparison of all decoders for one BG2 code.

Float decoders : BP (sum-product), MS, NMS (alpha), OMS (beta), neural NMS
Fixed point    : MS, NMS (12/16), neural NMS (trained k/16 weights)  -- bit-exact HW models
Writes results/<tag>/ber_fer.csv and ber_fer.png
"""
import argparse, csv
from pathlib import Path
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from ldpc_nms.code5g import BG2Code
from ldpc_nms.decoders import LayeredDecoder, FixedPointNMS
from ldpc_nms.channel import simulate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Z", type=int, default=16)
    ap.add_argument("--m", type=int, default=12)
    ap.add_argument("--iters", type=int, default=10)
    ap.add_argument("--neural", default="results/neural_edge", help="folder from train_neural.py")
    ap.add_argument("--share", default="edge")
    ap.add_argument("--ebn0", default="0.5,1.0,1.5,2.0,2.5,3.0,3.5")
    ap.add_argument("--min_fe", type=int, default=100)
    ap.add_argument("--max_frames", type=int, default=100_000)
    ap.add_argument("--q", default="6,7,5", help="q_ch,q_L,q_R")
    ap.add_argument("--scale", type=float, default=8.0)
    ap.add_argument("--alpha", type=float, default=0.75)
    ap.add_argument("--beta", type=float, default=0.5)
    ap.add_argument("--fx", default="results/neural_edge_fx_floor:floor",
                    help="comma list of dir:round_mode from train_fixed_aware.py")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="results/compare")
    a = ap.parse_args()

    ebn0 = [float(x) for x in a.ebn0.split(",")]
    q_ch, q_L, q_R = (int(x) for x in a.q.split(","))
    code = BG2Code(a.Z, a.m)
    print(code)
    T = a.iters

    neural = LayeredDecoder(code, T, "neural", share=a.share)
    neural.load_state_dict(torch.load(Path(a.neural) / "decoder.pt"))
    neural.weight_quant = None  # float weights after QAT (already on the k/16 grid)
    W_int = np.load(Path(a.neural) / "weights_int.npy")

    fx = dict(q_ch=q_ch, q_L=q_L, q_R=q_R, scale=a.scale)
    decs = {
        "BP (float)": (LayeredDecoder(code, T, "bp"), False),
        "MS (float)": (LayeredDecoder(code, T, "ms"), False),
        f"NMS a={a.alpha} (float)": (LayeredDecoder(code, T, "nms", alpha=a.alpha), False),
        f"OMS b={a.beta} (float)": (LayeredDecoder(code, T, "oms", beta=a.beta), False),
        "Neural NMS (float)": (neural, False),
        f"MS (fixed {q_ch}/{q_L}/{q_R})": (FixedPointNMS(code, T, w_int=16, **fx), True),
        f"NMS 12/16 (fixed {q_ch}/{q_L}/{q_R})": (FixedPointNMS(code, T, w_int=12, **fx), True),
        f"Neural NMS float-trained (fixed {q_ch}/{q_L}/{q_R})": (FixedPointNMS(code, T, w_int=W_int, **fx), True),
    }
    for item in filter(None, a.fx.split(",")):
        d, rm = item.split(":")
        Wfx = np.load(Path(d) / "weights_int.npy")
        decs[f"Neural NMS FX-aware {rm} (fixed {q_ch}/{q_L}/{q_R})"] = (
            FixedPointNMS(code, T, w_int=Wfx, round_mode=rm, **fx), True)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, (dec, use_y) in decs.items():
        print(name, flush=True)
        if isinstance(dec, torch.nn.Module):
            dec.eval()
        for r in simulate(code, dec, ebn0, min_frame_err=a.min_fe,
                          max_frames=a.max_frames, use_y=use_y, seed=a.seed):
            rows.append(dict(decoder=name, **r))
    with open(out / "ber_fer.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4.8))
    for name in decs:
        rr = [r for r in rows if r["decoder"] == name]
        x = [r["ebn0"] for r in rr]
        ls = "--" if "fixed" in name else "-"
        if "FX-aware" in name:
            ls = "-"
        for k, key in enumerate(["ber", "fer"]):
            y = [r[key] if r[key] > 0 else np.nan for r in rr]
            ax[k].semilogy(x, y, ls, marker="o", ms=4, label=name)
    for k, lab in enumerate(["BER", "FER"]):
        ax[k].set_xlabel("Eb/N0 (dB)"); ax[k].set_ylabel(lab); ax[k].grid(True, which="both", alpha=0.3)
    ax[1].legend(fontsize=7)
    fig.suptitle(f"BG2 Z={code.Z}, K={code.K}, N_tx={code.N_tx}, R={code.rate:.2f}, {T} layered iterations")
    fig.tight_layout(); fig.savefig(out / "ber_fer.png", dpi=150)
    print("saved", out)


if __name__ == "__main__":
    torch.set_num_threads(2)
    main()
